import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { supabase } from '../supabaseClient';
import AuthModule from './AuthModule';
import AdminDashboard from './AdminDashboard';
import ProviderJobBoard from './ProviderJobBoard';
import EarningsAndRevenue from './EarningsAndRevenue';

export default function App() {
  const [session, setSession] = useState(null);
  const [userRole, setUserRole] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) fetchUserRole(session.user);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) fetchUserRole(session.user);
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  async function fetchUserRole(user) {
    const { data, error } = await supabase.from('profiles').select('role').eq('id', user.id).single();
    if (error) console.error(error);
    else setUserRole(data.role);
  }

  if (!session) return <AuthModule setSession={setSession} />;

  return (
    <BrowserRouter>
      <Routes>
        {userRole === 'admin' ? (
          <>
            <Route path="/" element={<AdminDashboard />} />
            <Route path="/revenue" element={<EarningsAndRevenue isAdmin={true} />} />
            <Route path="*" element={<Navigate to="/" />} />
          </>
        ) : (
          <>
            <Route path="/" element={<ProviderJobBoard providerId={session.user.id} />} />
            <Route path="/earnings" element={<EarningsAndRevenue providerId={session.user.id} />} />
            <Route path="*" element={<Navigate to="/" />} />
          </>
        )}
      </Routes>
    </BrowserRouter>
  );
}
